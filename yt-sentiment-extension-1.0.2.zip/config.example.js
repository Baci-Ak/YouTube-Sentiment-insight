// Example config for the YouTube Sentiment Insights extension.
// Copy this file to `config.js` and edit values there.

window.APP_CONFIG = {
  // Local dev backend
  API_URL: 'http://localhost:5000',
};
