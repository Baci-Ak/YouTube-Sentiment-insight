// NOT COMMITTED TO GIT – local config for your extension
window.APP_CONFIG = {
  // Backend API (your Flask service behind EC2)
  API_URL: "http://54.242.62.191:8080",

  // YouTube Data API key
  YT_API_KEY: "AIzaSyDZ1pE4ga69Nj-GG0Q0s6KAQaHy8Jit-Mw"
};
